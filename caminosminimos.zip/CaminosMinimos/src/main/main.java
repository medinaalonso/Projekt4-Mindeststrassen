package main;


import grafo.G;
import grafo.teorias;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import grafo.v;
import java.util.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Set;
import java.util.Scanner;   
import java.util.Random;

public class main {

    public static void main(String[] args) throws Exception {
        try {
            int num,dir,teo,auto;
       
        System.out.println("¿Cual modelo quieres?");
        System.out.println("1-Erdos & Renyi");
        System.out.println("2-Gilbert");
        System.out.println("3-Geografico Simple");
        System.out.println("4-Barabasi-Albert");
        System.out.println("5-Todos");
        Scanner t = new Scanner(System.in);
        teo = t.nextInt();
        System.out.println("¿Dirigido o no dirigido, 1,0?");
        Scanner v = new Scanner(System.in);
        dir = v.nextInt(); 
        System.out.println("Auto dirigido o no auto dirigido, 1,0?");
        Scanner a = new Scanner(System.in);
        auto = a.nextInt(); 
       switch (teo) {
      case 1:
             G erdos30 = teorias.Erdos(30, 15, false);
            G wgErdos30 = erdos30.ladoValues(1, 100);
            wgErdos30.PrintToFile(false, true, false, "Erdos(30)");
            G kdErdos30 = wgErdos30.Kruskal();
            kdErdos30.PrintToFile(false, true, true, "ErdosK(30)");
            G kiErdos30 = wgErdos30.KruskalI();
            kiErdos30.PrintToFile(false, true, true, "ErdosKI(30)");
            G primErdos30 = wgErdos30.Prim();
            primErdos30.PrintToFile(false, true, true, "ErdosPrim(30)");

            G erdos100 = teorias.Erdos(100, 3000, false);
            G wgErdos100 = erdos100.ladoValues(1, 100);
            wgErdos100.PrintToFile(false, true, false, "Erdos(100)");
            G kdErdos100 = wgErdos100.Kruskal();
            kdErdos100.PrintToFile(false, true, true, "ErdosK(100)");
            G kiErdos100 = wgErdos100.KruskalI();
            kiErdos100.PrintToFile(false, true, true, "ErdosKI(100)");
            G primErdos100 = wgErdos100.Prim();
            primErdos100.PrintToFile(false, true, true, "ErdosPrim(100)");

            G erdos500 = teorias.Erdos(500, 3000, false);
            G wgErdos500 = erdos500.ladoValues(1, 100);
            wgErdos500.PrintToFile(false, true, false, "Erdos(500)");
            G kdErdos500 = wgErdos500.Kruskal();
            kdErdos500.PrintToFile(false, true, true, "ErdosK(500)");
            G kiErdos500 = wgErdos500.KruskalI();
            kiErdos500.PrintToFile(false, true, true, "ErdosKI(500)");
            G primErdos500 = wgErdos500.Prim();
            primErdos500.PrintToFile(false, true, true, "ErdosPrim(500)");
    break;      
    case 2:
            G gil30 = teorias.Gilbert(30, 0.45, false);
            G wgGil30 = gil30.ladoValues(1, 100);
            wgGil30.PrintToFile(false, true, false, "Gilbert(30)");
            G kdGil30 = wgGil30.Kruskal();
            kdGil30.PrintToFile(false, true, true, "GilbertK(30)");
            G kiGil30 = wgGil30.KruskalI();
            kiGil30.PrintToFile(false, true, true, "GilbertKI(30)");
            G primGil30 = wgGil30.Prim();
            primGil30.PrintToFile(false, true, true, "GilbertPrim(30)");

            G gil100 = teorias.Gilbert(100, 0.45, false);
            G wgGil100 = gil100.ladoValues(1, 100);
            wgGil100.PrintToFile(false, false, false, "Gilbert(100)");
            G kdGil100 = wgGil100.Kruskal();
            kdGil100.PrintToFile(false, true, true, "GilbertK(100)");
            G kiGil100 = wgGil100.KruskalI();
            kiGil100.PrintToFile(false, true, true, "GilbertKI(100)");
            G primGil100 = wgGil100.Prim();
            primGil100.PrintToFile(false, true, true, "GilbertPrim(100)");
           
            G gil500 = teorias.Gilbert(500, 0.45, false);
            G wgGil500 = gil500.ladoValues(1, 100);
            wgGil500.PrintToFile(false, false, false, "Gilbert(500)");
            G kdGil500 = wgGil500.Kruskal();
            kdGil500.PrintToFile(false, true, true, "GilbertK(500)");
            G kiGil500 = wgGil500.KruskalI();
            kiGil500.PrintToFile(false, true, true, "GilbertKI(500)");
            G primGil500 = wgGil500.Prim();
            primGil500.PrintToFile(false, true, true, "GilbertPrim(500)");
    break;      
    case 3:
             G barabasi30 = teorias.CreateBarabasiAlbertG(30, 5, false);
            G wgBarabasi30 = barabasi30.ladoValues(1, 100);
            wgBarabasi30.PrintToFile(false, true, false, "Barabasi(30)");
            G kdBarabasi30 = wgBarabasi30.Kruskal();
            kdBarabasi30.PrintToFile(false, true, true, "BarabasiK(30)");
            G kiBarabasi30 = wgBarabasi30.KruskalI();
            kiBarabasi30.PrintToFile(false, true, true, "BarabasiKI(30)");
            G primBarabasi30 = wgBarabasi30.Prim();
            primBarabasi30.PrintToFile(false, true, true, "BarabasiPrim(30)");

            G barabasi100 = teorias.CreateBarabasiAlbertG(100, 4, false);
            G wgBarabasi100 = barabasi100.ladoValues(1, 100);
            wgBarabasi100.PrintToFile(false, true, false, "Barabasi(100)");
            G kdBarabasi100 = wgBarabasi100.Kruskal();
            kdBarabasi100.PrintToFile(false, true, true, "BarabasiK(100)");
            G kiBarabasi100 = wgBarabasi100.KruskalI();
            kiBarabasi100.PrintToFile(false, true, true, "BarabasiKI(100)");
            G primBarabasi100 = wgBarabasi100.Prim();
            primBarabasi100.PrintToFile(false, true, true, "BarabasiPrim(100)");
           
            G barabasi500 = teorias.CreateBarabasiAlbertG(500, 4, false);
            G wgBarabasi500 = barabasi500.ladoValues(1, 100);
            wgBarabasi100.PrintToFile(false, true, false, "Barabasi(500)");
             G kdBarabasi500 = wgBarabasi500.Kruskal();
            kdBarabasi500.PrintToFile(false, true, true, "BarabasiK(500)");
            G kiBarabasi500 = wgBarabasi500.KruskalI();
            kiBarabasi500.PrintToFile(false, true, true, "BarabasiKI(500)");
            G primBarabasi500 = wgBarabasi500.Prim();
            primBarabasi500.PrintToFile(false, true, true, "BarabasiPrim(500)");
    break;      
    case 4:
         G geo30 = teorias.Geo(30, 0.5, false);
            G wgGeo30 = geo30.ladoValues(1, 100);
            wgGeo30.PrintToFile(false, true, false, "Geo(30)");
            G kdGeo30 = wgGeo30.Kruskal();
            kdGeo30.PrintToFile(false, true, true, "GeoK(30)");
            G kiGeo30 = wgGeo30.KruskalI();
            kiGeo30.PrintToFile(false, true, true, "GeoKI(30)");
            G primGeo30 = wgGeo30.Prim();
            primGeo30.PrintToFile(false, true, true, "GeoPrim(30)");

            G geo100 = teorias.Geo(100, 0.2, false);
            G wgGeo100 = geo100.ladoValues(1, 100);
            wgGeo100.PrintToFile(false, true, false, "Geo(100)");
            G kdGeo100 = wgGeo100.Kruskal();
            kdGeo100.PrintToFile(false, true, true, "GeoK(100)");
            G kiGeo100 = wgGeo100.KruskalI();
            kiGeo100.PrintToFile(false, true, true, "GeoKI(100)");
            G primGeo100 = wgGeo100.Prim();
            primGeo100.PrintToFile(false, true, true, "GeoPrim(100)");
           
            G geo500 = teorias.Geo(500, 0.2, false);
            G wgGeo500 = geo500.ladoValues(1, 100);
            wgGeo500.PrintToFile(false, true, false, "Geo(500)");
            G kdGeo500 = wgGeo500.Kruskal();
            kdGeo500.PrintToFile(false, true, true, "GeoK(500)");
            G kiGeo500 = wgGeo500.KruskalI();
            kiGeo500.PrintToFile(false, true, true, "GeoKI(500)");
            G primGeo500 = wgGeo500.Prim();
            primGeo500.PrintToFile(false, true, true, "GeoPrim(500)");
          
       }
            
        } catch (Exception ex) {
            System.out.print(ex.getMessage());
        }
    }

}




	
	
	

