package grafo;

public class v implements Comparable<v> {
    

    public Integer id;
    
    public Integer grado;

    public Float distancia;
    

    public String obtener;
    

    public Boolean marcado;
    

    public v padre;
   
    public Double X;
    

    public Double Y;
  
    public Integer z;
    
    public v(int id){
        this.id = id;
    }
    
    @Override
    public int compareTo(v otro) {
        if (this.distancia < otro.distancia){
            return -1;
        } else if (this.distancia > otro.distancia){
            return 1;
        } else {
          return 0;
        }
    }
}
