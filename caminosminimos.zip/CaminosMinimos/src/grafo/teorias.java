package grafo;


import java.util.HashMap;
import java.util.Random;


public class teorias{
    
    public static G Gilbert(Integer gradov, Double probability, Boolean ciclico) {
    
        if(probability< 0.0 || probability>1.0){
           throw new IllegalArgumentException("Probability must be less or equal than 1.0 and greater than 0");
        }
        
        G result = new G();
        result.obtener = "Gilbert";
        result.isDirected = false;
        result.ciclico = ciclico;
        
        int startingPoint = ciclico ? 0 : 1;
        for(int vertex = 1; vertex <= gradov;vertex++){
            v vertexAux = new v(vertex);
            result.Addv(vertex, vertexAux);
            for(int nextv = vertex + startingPoint; nextv<=gradov; nextv++){
                if(IsSuccess(probability)){
                    lado edgeAux = new lado();
                    edgeAux.n1 = vertex;
                    edgeAux.n2 = nextv;
                    result.Addlado(vertex+"-"+nextv, edgeAux);  
                }
            }
        }
        
        return result;
    }
        
    public static G Erdos(Integer gradov, Integer edgeNumber, Boolean ciclico) {
        if(gradov == 0 || edgeNumber == 0){
            throw new IllegalArgumentException("Number of vertices and lados must be greater than zero");
        }
        
        if((gradov*gradov)<(edgeNumber)){
            throw new IllegalArgumentException("Invalid number of lados.");
        }
    
      
        G result = new G();
        result.obtener = "ErdosRenyi";
        result.isDirected = false;
        result.ciclico = ciclico;
        result.vertices = new HashMap<>();
        for(int vertexCreated = 1; vertexCreated <= gradov;vertexCreated++){
            v item = new v(vertexCreated);
            result.Addv(vertexCreated, item);
        }
        
     
        result.lados = new HashMap();
        for(int edgeCreated = 1; edgeCreated <= edgeNumber;edgeCreated++){
            Integer source = CreateRandomInteger(1,gradov);
            Integer target = CreateRandomInteger(1,gradov);
            
            if(!ExistOnG(result, source, target)) {
                if(!ciclico && (source.equals(target))) {
                    edgeCreated--;
                } else {
                    lado newlado = new lado();
                    newlado.n1 = source;
                    newlado.n2 = target;
                    result.Addlado(source+"-"+target, newlado);
                }
            } else {
                edgeCreated--;
            }
        }
        
        return result;
    }

    public static G Geo(Integer gradov, Double distancia, Boolean ciclico) {
        G result = new G();
        result.obtener = "Geographical";
        result.isDirected = false;
        result.ciclico = ciclico;
        result.vertices = new HashMap<>();
        
        for(int vertexCreated = 1; vertexCreated <=gradov;vertexCreated++){
            v item = new v(vertexCreated);
            item.X = CreateRandomNumber();
            item.Y = CreateRandomNumber();
            result.Addv(vertexCreated, item);
        }
         
        int startingPoint = ciclico ? 0 : 1;
        result.lados = new HashMap();
        for(int i = 1; i <= gradov; i++){
            for(int j = i + startingPoint; j<= gradov; j++){
                Double euclideanDistance = Math.sqrt(Math.pow(result.vertices.get(i).X - result.vertices.get(j).X,2) + Math.pow(result.vertices.get(i).Y - result.vertices.get(j).Y,2));
                if(euclideanDistance <= distancia) {
                    lado newlado = new lado();
                    newlado.n1 = i;
                    newlado.n2 = j;
                    result.Addlado(i+"-"+j, newlado);
                }
            }          
        }

        
        return result;
    }
    
    public static G CreateBarabasiAlbertG(Integer gradov, Integer gradoV, Boolean ciclico) {
        G result = new G();
        result.obtener = "BarabasiAlbert";
        result.isDirected = false;
        result.ciclico = ciclico;
        result.vertices = new HashMap<>();

        result.lados = new HashMap();
        double p = 0.0;
        for(int i = 1; i <= gradov; i++){
            v item = new v(i);
            item.grado = 0;
            result.Addv(i, item);
            for(int j = 1; j<= result.vertices.size(); j++){
                if(result.vertices.get(i).grado<=gradoV){
                    if((i==j)&&!ciclico) {
                        continue;
                    } else {
                        p = 1 - (result.vertices.get(j).grado/Double.valueOf(gradoV));
                        if (CreateRandomNumber() < p) {
                            lado newlado = new lado();
                            newlado.n1 = i;
                            newlado.n2 = j;
                            result.Addlado(i+"-"+j, newlado);
                            result.vertices.get(i).grado += 1;
                            if(i!=j){
                                result.vertices.get(j).grado += 1;
                            }
                        }
                    }
                } else {
                    break;
                }
            }          
        } 
        
        return result;
    }
     
    public static Boolean ExistOnG(G graph, Integer source, Integer target){       
        Boolean exist = graph.lados.containsKey(source+"-"+target);
        Boolean existBackwards = graph.lados.containsKey(target+"-"+source);
            
        return (exist || existBackwards);
    }
    
     private static double CreateRandomNumber() {
        Random random = new Random();
        return random.nextDouble();
    }
    
     private static int CreateRandomInteger(Integer minNumber, Integer maxNumber){
         Random random =  new Random();
         return random.nextInt((maxNumber - minNumber) + 1) + minNumber;
     }   
     
     private static boolean IsSuccess(double p) {
        if (!(p >= 0.0 && p <= 1.0))
            throw new IllegalArgumentException("invalid probability 2");
        return CreateRandomNumber() < p;
    }
    
}
