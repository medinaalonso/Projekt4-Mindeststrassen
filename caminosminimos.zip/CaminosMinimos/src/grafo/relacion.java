package grafo;

import java.util.*;

public class relacion<T>
{

    private Map<T, T> padre;

    private Map<T, Integer> rango;

    private int components; 

    public relacion(Set<T> nodos)
    {
        padre = new LinkedHashMap<>();
        rango = new HashMap<>();
        for (T nodo : nodos) {
            padre.put(nodo, nodo);
            rango.put(nodo, 0);
        }
        components = nodos.size();
    }

    public T Find(T nodo)
    {
        if (!padre.containsKey(nodo)) {
            throw new IllegalArgumentException("The nodo is not contained in this UnionFind structure");
        }

        T current = nodo;
        while (true) {
            T padre = this.padre.get(current);
            if (padre.equals(current)) {
                break;
            }
            current = padre;
        }
        T base = current;

        current = nodo;
        while (!current.equals(base)) {
            T padre = this.padre.get(current);
            this.padre.put(current, base);
            current = padre;
        }

        return base;
    }

    public void Union(T n1, T n2)
    {
        if (!padre.containsKey(n1) || !padre.containsKey(n2)) {
            throw new IllegalArgumentException("One or both nodos could not be found in the UnioFind structure.");
        }

        T padre1 = Find(n1);
        T hijo = Find(n2);

        if (padre1.equals(hijo)) {
            return;
        }

        int rango1 = rango.get(padre1);
        int rango2 = rango.get(hijo);
        if (rango1 > rango2) {
            padre.put(hijo, padre1);
        } else if (rango1 < rango2) {
            padre.put(padre1, hijo);
        } else {
            padre.put(hijo, padre1);
            rango.put(padre1, rango1 + 1);
        }
        components--;
    }

    public boolean InSameSet(T n1, T n2)
    {
        return Find(n1).equals(Find(n2));
    }
}