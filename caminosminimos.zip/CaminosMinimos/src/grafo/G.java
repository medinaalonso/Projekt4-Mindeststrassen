package grafo;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Random;
import java.util.Stack;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;


public class G{
    
    public String obtener;
    
    private Double totalWeight;
    
    public Integer vertexCount;
    
    public Integer ladosCount;
    
    private G dfsTree;
    
    public HashMap<String, lado> lados;
    
    public HashMap<Integer, v> vertices;
    
 
    public HashMap<Integer, ArrayList<Integer>> adjacencyList;
    
    public Boolean isDirected;
    

    public Boolean ciclico;
      
 
    public G(){
        this.vertices = new HashMap<>();
        this.lados = new HashMap();
        this.adjacencyList = new HashMap<>();
    }
    

    public void Addv(Integer id, v vertex ){
        this.vertices.put(id, vertex);
    }
    

    public void Addlado(String id, lado edge){
        this.lados.put(id, edge);
        AddvAdjList(edge.n1);
        AddvAdjList(edge.n2);
        
        if (!(this.adjacencyList.containsKey(edge.n1) && this.adjacencyList.get(edge.n1).contains(edge.n2))) { 
            this.adjacencyList.get(edge.n1).add(edge.n2);
        }  
        if (!(this.adjacencyList.containsKey(edge.n2) && this.adjacencyList.get(edge.n2).contains(edge.n1))) { 
            this.adjacencyList.get(edge.n2).add(edge.n1);
        }
    }
    
 
    private void AddvAdjList(Integer id) {
        if (!this.adjacencyList.containsKey(id)) {
            this.adjacencyList.put(id, new ArrayList<>());
        }
    }

    public G BFS(v sourcev) {
        if (!this.vertices.containsKey(sourcev.id)) {
            throw new IllegalArgumentException("The vertex is not contained in this graph.");
        } 
        
        v s = this.vertices.get(sourcev.id);
        Queue<v> q = new LinkedList();
        this.vertices.forEach((Integer key,v value) -> {
            value.marcado = false;
        });
        
        s.marcado = true;
        q.add(sourcev);
        G bfsTree = new G();
        bfsTree.vertices = this.vertices;  
        bfsTree.obtener = "BFSTree";
        bfsTree.isDirected = false;
        
        while(!q.isEmpty()){
            v u = q.poll();

            for(Integer adj : this.adjacencyList.get(u.id)) {   
                v v = this.vertices.get(adj);
                if(!v.marcado) {
                    v.marcado = true;
                    lado auxlado =  Getlado(u.id,v.id);
                    bfsTree.Addlado(u.id+"-"+v.id, auxlado);
                    q.add(v);
                }
            }
        }        
        return bfsTree;
    }
    
    public G DFS_R(v sourcev) {
        if (!this.vertices.containsKey(sourcev.id)) {
            throw new IllegalArgumentException("The vertex is not contained in this graph.");
        } 
        
        v source = this.vertices.get(sourcev.id);   
        this.dfsTree = new G();
        this.dfsTree.vertices = this.vertices;  
        this.dfsTree.obtener = "DFS_R_Tree";
        this.dfsTree.isDirected = false;
        
        this.vertices.forEach((Integer key,v value) -> {
            value.padre = null;
            value.marcado = false;
        });
             
        DFS_Recursive(source);
        
        return dfsTree;
    }
    

    private void DFS_Recursive(v u) {
         u.marcado = true;
         for(int adjv:this.adjacencyList.get(u.id)) {
             v v = this.vertices.get(adjv);
             if (!v.marcado) {  
                 v.padre = u;    
                 lado auxlado =  Getlado(u.id,v.id);
                 this.dfsTree.Addlado(u.id+"-"+v.id, auxlado); 
                 DFS_Recursive(v);         
             }
         }
    }
    
 
    public G DFS_I(v sourcev) {
        if (!this.vertices.containsKey(sourcev.id)) {
            throw new IllegalArgumentException("The vertex is not contained in this graph.");
        }
        
        v source = this.vertices.get(sourcev.id);   
        
        Stack<v> s = new Stack<>();
        s.add(source);
        G dfsTree = new G();
        dfsTree.vertices = this.vertices;  
        dfsTree.obtener = "DFS_I_Tree";
        dfsTree.isDirected = false;
        
        this.vertices.forEach((Integer key,v value) -> {
            value.padre = null;
            value.marcado = false;
        });
        
        while(!s.isEmpty()) {
            v u = s.peek();
            if (!u.marcado) {
                u.marcado = true;
                if(!Objects.equals(u.id, source.id)) {
                    lado auxlado = Getlado(u.id,u.padre.id);
                    dfsTree.Addlado(u.id+"-"+u.padre.id, auxlado);
                }

                for(Integer adj:this.adjacencyList.get(u.id)) {   
                    v v = this.vertices.get(adj);
                    s.push(v);
                    v.padre = u;
                }
            } else {
                s.pop();
            }
        }
        
        return dfsTree;
    }
    
  
    public G ladoValues(float min, float max) { 
        Random random =  new Random(); 
        
        this.lados.forEach((String key, lado value) -> {
            value.peso = (random.nextFloat() * (max-min)) + min;
        });
        
        return this;
    }
    
    
  
    private boolean IsConnected(){
        DFS_R(new v(1));
        
        for(v v: this.vertices.values()){
            if(!v.marcado){
                return false;
            }
        }
        
        return true;
    }
    
 
    public G Kruskal(){
        PriorityQueue<lado> pqueue = new PriorityQueue<>();
        G MST = new G();
        MST.obtener =  "KruskalD_MST";
        MST.vertices = this.vertices;
        MST.isDirected = false; 
        MST.totalWeight=0.0;
        relacion UF = new relacion(new HashSet<>(this.vertices.values())); 
        
        this.lados.forEach((String key,lado value) -> {
            pqueue.add(value);
        });
        
        for (int i=0; i<this.lados.size(); i++) {
            lado e = pqueue.remove();
            if(!UF.InSameSet(this.vertices.get(e.n1), this.vertices.get(e.n2))){
                MST.Addlado(e.n1+"-"+e.n2, e);
                MST.totalWeight += e.peso;
                UF.Union(this.vertices.get(e.n1), this.vertices.get(e.n2));
            }
        }
        
        System.out.println("Peso del MST generado por Kruskal directo: " + MST.totalWeight);
        return MST;
    }
    
    public G KruskalI(){
        G MST = new G();
        MST.obtener = "KruskalI_MST";
        MST.totalWeight = 0.0;
        MST.isDirected = false;
        
        this.vertices.forEach((Integer key, v value) -> {
            MST.Addv(key, value);
        });
        
        this.lados.forEach((String key, lado value) -> {
            MST.Addlado(key, value);
        });

        ArrayList<lado> orderedlados = new ArrayList(this.lados.values());
        Collections.sort(orderedlados, Collections.reverseOrder());
        
        for (lado e: orderedlados) {         
            MST.adjacencyList.get(e.n1).remove(e.n2); 
            MST.adjacencyList.get(e.n2).remove(e.n1); 
            if(!MST.IsConnected()){
                MST.adjacencyList.get(e.n1).add(e.n2);
                MST.adjacencyList.get(e.n2).add(e.n1);                
            } else {
                if(MST.lados.containsKey(e.n1+"-"+e.n2)){
                    MST.lados.remove(e.n1+"-"+e.n2);
                }
                if(MST.lados.containsKey(e.n2+"-"+e.n1)){
                    MST.lados.remove(e.n2+"-"+e.n1);
                }
            }            
        }
        
        MST.lados.forEach((String key, lado value) -> {
            MST.totalWeight += value.peso;
        });
        
        System.out.println("Peso del MST generado por Kruskal inverso: " + MST.totalWeight);
        
        return MST;
    }
    
    public G Prim() {
        PriorityQueue<v> pqueue = new PriorityQueue<>();
        G mst = new G();
        mst.vertices = this.vertices;
        mst.isDirected = false;
        mst.lados = new HashMap<>();
        mst.obtener = "Prim_MST";
        mst.totalWeight = 0.0;

        this.vertices.forEach((Integer key, v value) -> {
            value.distancia = Float.POSITIVE_INFINITY;
            value.marcado = false;
            value.padre = null;
            pqueue.add(value);
        });
        
        while(!pqueue.isEmpty()) {
            v u = pqueue.remove();
            u.marcado = true;
            
            if(u.padre!=null){
                lado mstlado = new lado();
                mstlado.n1 = u.padre.id;
                mstlado.n2 = u.id;
                mstlado.peso = Getlado(mstlado.n1,mstlado.n2).peso;
                mst.Addlado(mstlado.n1+"-"+mstlado.n2, mstlado);
                mst.totalWeight += mstlado.peso;
            }
                 
            for (Integer value : this.adjacencyList.get(u.id)) {  
                v v = this.vertices.get(value);
                if(!v.marcado && (v.distancia > Getlado(u.id,value).peso)){
                    v.distancia = Getlado(u.id,value).peso;
                    v.padre = u;
                    if (pqueue.contains(v)){
                        pqueue.remove(v);
                    }
                    pqueue.add(v);
                }
            }
        }
        
        System.out.println("Peso del MST generado por Prim: " + mst.totalWeight);
        
        return mst;
    }
    
    public lado Getlado(Integer node1, Integer node2) {
        String edgeKey = this.lados.containsKey(node1+"-"+node2) ? node1+"-"+node2 : "" ;
        edgeKey = this.lados.containsKey(node2+"-"+node1) ? node2+"-"+node1 : edgeKey;
        
        return this.lados.containsKey(edgeKey) ? this.lados.get(edgeKey) : null;
    }
    
    public void PrintToFile(boolean showDistance, boolean showvWeight, boolean ShowTotalWeight, String name) throws FileNotFoundException{
                
        PrintWriter writter = new PrintWriter(name+".gv");
        String separator;
        if(this.isDirected){
            writter.print("digraph ");
            separator = " -> ";
        }
        else
        {
            writter.print("graph ");
            separator = " -- ";
        }
        
        writter.print(this.obtener);
        writter.print("{");
        
        this.vertices.forEach((Integer key, v value) -> {
            String idv = value.id.toString();
            String label = " [label = \"Nodo"+idv;
            if(showDistance){
                label = label +" ("+value.distancia+")";
            }
            if(ShowTotalWeight&&(value.id==1)){               
                label = " [label = \"PesoTotal = "+this.totalWeight;
            }              
            writter.println(idv+label+"\"];");
        });
        
        this.lados.forEach((String key, lado value) -> {
            String source = value.n1.toString();
            String target  = value.n2.toString();
            String label = "";
            if(showvWeight){
                label = " [label = \""+value.peso+"\"]";
            }
            writter.println(source+separator+target+label+";");
        });
        
        writter.print("}");
        writter.close();      
    }
}

