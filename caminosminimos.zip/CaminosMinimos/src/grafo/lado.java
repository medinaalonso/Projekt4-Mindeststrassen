package grafo;

public class lado implements Comparable<lado> { 
    

    public Integer Id;

    public Integer n1;
    
    public Integer n2 ;
    
  
    public Float peso;
    
    @Override
    public int compareTo(lado otro) {  
        return this.peso > otro.peso ? 1 : this.peso < otro.peso? -1 : 0;  
    }
}
